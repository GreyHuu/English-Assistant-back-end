package com.se1722.englishassistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnglishAssistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
