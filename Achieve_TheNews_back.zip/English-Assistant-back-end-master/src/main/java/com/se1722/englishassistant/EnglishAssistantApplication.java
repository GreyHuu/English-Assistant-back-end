package com.se1722.englishassistant;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class EnglishAssistantApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnglishAssistantApplication.class, args);
	}

}
